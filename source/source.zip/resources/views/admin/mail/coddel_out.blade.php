<html>
    <body>
        <p>Out For Delivery: Your order id #{{$cart_id}} contains of {{$prod_name}} of price {{$currency_sign}} {{$price2}} is Out For Delivery.Get ready with {{$currency->currency_sign}} {{$rem_price}} cash.</p>
    </body>
</html>