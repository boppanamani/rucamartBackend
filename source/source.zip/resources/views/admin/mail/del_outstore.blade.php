<html>
    <body>
        <p>Out For Delivery: Order id #{{$cart_id}} contains of {{$prod_name}} of price {{$currency_sign}} {{$price2}} is Out For Delivery.{{dboy_name}} will deliver the Order.</p>
    </body>
</html>