<html>
    <body>
        <p>Order Cancelled: Order id #{{$cart_id}} contains of {{$prod_name}} of price {{$currency_sign}} {{$price2}} has been cancelled by {{$user_name}}({{$user_phone}}).</p>
    </body>
</html>