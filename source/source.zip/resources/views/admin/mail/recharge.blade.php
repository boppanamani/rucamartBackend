<html>
    <body>
        <p>
       Hi {{$user_name}}, Your Recharge for amount of {{$currency_sign}} {{$add_to_wallet}} is successful.Check your wallet"
        </p>
    </body>
</html>